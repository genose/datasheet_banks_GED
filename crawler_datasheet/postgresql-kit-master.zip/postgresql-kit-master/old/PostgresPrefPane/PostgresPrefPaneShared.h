
extern NSString* PostgresServerAppIdentifier;

