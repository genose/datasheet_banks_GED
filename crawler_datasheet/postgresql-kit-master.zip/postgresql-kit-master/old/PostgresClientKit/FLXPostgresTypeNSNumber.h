
@interface FLXPostgresTypeNSNumber : NSObject <FLXPostgresTypeProtocol> {
	FLXPostgresConnection* m_theConnection;
}

@end

