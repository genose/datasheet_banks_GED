
#import <Cocoa/Cocoa.h>
#import <PGClientKit/PGClientKit.h>
#import <PGControlsKit/PGControlsKit.h>

@interface AppDelegate : NSObject <NSApplicationDelegate,PGDialogDelegate,PGConnectionDelegate>

@end

