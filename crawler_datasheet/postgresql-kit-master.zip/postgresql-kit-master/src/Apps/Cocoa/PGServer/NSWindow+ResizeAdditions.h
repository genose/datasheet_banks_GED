
#import <Cocoa/Cocoa.h>

@interface NSWindow (ResizeAdditions)
-(void)resizeToSize:(NSSize)newSize;
@end
