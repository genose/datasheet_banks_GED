
NSString* PostgresServerAppIdentifier = @"com.mutablelogic.PostgresServerApp";
